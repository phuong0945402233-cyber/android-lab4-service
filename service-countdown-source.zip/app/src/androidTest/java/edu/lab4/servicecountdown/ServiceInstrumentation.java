package edu.lab4.servicecountdown;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Activity;
import android.app.Instrumentation;
import android.app.NotificationManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.TextView;
import android.util.Xml;
import org.json.JSONArray;
import org.json.JSONObject;
import org.xmlpull.v1.XmlSerializer;
import java.io.File;
import java.io.FileOutputStream;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;

/** Runs on the real Android framework and captures original device pixels. */
public final class ServiceInstrumentation extends Instrumentation {
    private MainActivity main;
    private CountdownService runningService;
    private final JSONArray assertions = new JSONArray();
    private final JSONArray timeline = new JSONArray();
    private final StringBuilder log = new StringBuilder();
    private int checks;
    private long firstDeadline;
    private long firstObservedStart;
    private long firstFinishObserved;
    private long secondDeadline;
    private long secondFinishObserved;
    private int bootDialogsWaited;

    @Override public void onCreate(Bundle args) { super.onCreate(args); start(); }
    @Override public void onStart() {
        Bundle result = new Bundle();
        try {
            AccessibilityServiceInfo info = getUiAutomation().getServiceInfo();
            info.flags |= AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS;
            getUiAutomation().setServiceInfo(info);
            clearBootDialog();
            main = launchMain();
            awaitConnected(main);
            clearBootDialog();
            check(snap(main).seconds == 0 && snap(main).enabled, "TC01 初始按钮可点击且无倒计时");
            check(snap(main).button.equals("获取验证码"), "TC01 初始按钮文字正确");
            record("initial", main); screenshot("01_initial");

            firstObservedStart = SystemClock.elapsedRealtime();
            click(main, R.id.get_code);
            await(() -> snap(main).seconds > 0, 10000, "Countdown did not start");
            runningService = service(main);
            firstDeadline = deadline(runningService);
            Snapshot active = snap(main);
            check(active.seconds >= 58 && active.seconds <= 60, "TC02 Service启动60秒倒计时");
            check(!active.enabled && active.button.contains("秒后重新获取"), "TC02 倒计时按钮禁用并显示剩余秒数");
            check(firstDeadline - firstObservedStart >= 60000 && firstDeadline - firstObservedStart <= 64000,
                    "TC02 单调时钟截止时刻对应完整60秒");
            check(notificationPresent(), "TC02 前台服务通知已创建");
            record("started", main); screenshot("02_started");

            int beforeTick = snap(main).seconds;
            SystemClock.sleep(1400);
            Snapshot afterTick = snap(main);
            check(afterTick.seconds < beforeTick && afterTick.seconds > 0, "TC03 一秒节拍推进剩余时间");
            check(afterTick.button.equals(afterTick.seconds + " 秒后重新获取"), "TC03 按钮文字与服务剩余秒数一致");
            getTargetContext().startForegroundService(new Intent(getTargetContext(), CountdownService.class)
                    .setAction(CountdownService.ACTION_START));
            settle();
            check(deadline(runningService) == firstDeadline, "TC04 重复启动请求不延长或重置倒计时");
            record("duplicate_request", main); screenshot("03_tick_and_lock");

            ActivityMonitor otherMonitor = addMonitor(AnotherActivity.class.getName(), null, false);
            click(main, R.id.navigate);
            Activity opened = waitForMonitorWithTimeout(otherMonitor, 15000);
            check(opened instanceof AnotherActivity, "TC05 成功切换到第二个Activity");
            MainActivity other = (MainActivity) opened;
            awaitConnected(other); settle();
            check(service(other) == runningService && deadline(service(other)) == firstDeadline,
                    "TC05 两个页面共享同一Service和截止时间");
            int otherBefore = snap(other).seconds;
            SystemClock.sleep(1500);
            check(snap(other).seconds < otherBefore && !snap(other).enabled, "TC05 第二个页面继续接收每秒状态");
            check(listenerCount(runningService) == 1, "TC05 不可见Activity已解除回调，只有当前页面订阅");
            record("second_activity", other); screenshot("04_second_activity");
            removeMonitor(otherMonitor);

            openExternalSettings();
            await(() -> listenerCount(runningService) == 0, 15000, "Activity did not stop after leaving the app");
            int beforeHomeWait = remaining(runningService);
            check(listenerCount(runningService) == 0, "TC06 切换至系统设置后所有Activity均解绑");
            check(activePackage().equals("com.android.settings"), "TC06 实际前台为系统设置，实验应用已进入后台");
            SystemClock.sleep(7000);
            check(remaining(runningService) <= beforeHomeWait - 5 && remaining(runningService) > 0,
                    "TC06 无界面绑定时前台服务继续倒计时");
            settle(); screenshot("05_background_settings");
            main = launchMain(); awaitConnected(main);
            check(deadline(service(main)) == firstDeadline && snap(main).seconds <= beforeHomeWait - 5
                    && !snap(main).enabled, "TC07 返回前台立即显示当前秒数且不重置60秒");
            record("returned_from_home", main); screenshot("06_returned");

            ActivityMonitor recreate = addMonitor(MainActivity.class.getName(), null, false);
            MainActivity previous = main;
            runOnMainSync(previous::recreate);
            Activity created = waitForMonitorWithTimeout(recreate, 15000);
            if (!(created instanceof MainActivity)) throw new AssertionError("Activity recreation failed");
            main = (MainActivity) created; awaitConnected(main); removeMonitor(recreate);
            check(main != previous && deadline(service(main)) == firstDeadline && !snap(main).enabled,
                    "TC08 Activity销毁重建后继续原倒计时");
            record("activity_recreated", main); screenshot("07_recreated");

            await(() -> snap(main).seconds <= 5, 70000, "Final seconds not reached");
            record("last_seconds", main); screenshot("08_last_seconds");
            await(() -> snap(main).seconds == 0 && snap(main).enabled, 15000, "Button did not recover");
            firstFinishObserved = SystemClock.elapsedRealtime();
            check(firstFinishObserved >= firstDeadline, "TC09 第一次完整倒计时未提前结束");
            check(snap(main).button.equals("获取验证码") && snap(main).enabled,
                    "TC09 结束后按钮恢复原文并可再次点击");
            check(!notificationPresent(), "TC09 结束后移除前台服务通知");
            record("first_finished", main); screenshot("09_completed");

            click(main, R.id.get_code);
            await(() -> snap(main).seconds > 0, 10000, "Second countdown did not start");
            CountdownService secondService = service(main);
            secondDeadline = deadline(secondService);
            check(secondDeadline > firstDeadline && !snap(main).enabled, "TC10 倒计时结束后能够开始第二个60秒周期");
            record("second_cycle_started", main);
            openExternalSettings();
            while (SystemClock.elapsedRealtime() < secondDeadline + 2000) SystemClock.sleep(300);
            secondFinishObserved = SystemClock.elapsedRealtime();
            main = launchMain(); awaitConnected(main);
            check(snap(main).seconds == 0 && snap(main).enabled && snap(main).button.equals("获取验证码"),
                    "TC11 在后台跨过截止时间后返回，按钮保持可用");
            check(!notificationPresent() && !snap(main).running, "TC11 后台周期结束后服务前台任务和通知均已结束");
            record("finished_while_background", main); screenshot("10_background_finished");

            log.append("RESULT: PASS; checks=").append(checks).append('\n');
            writeResults(true, "");
            result.putString("stream", "\n" + log);
            finish(Activity.RESULT_OK, result);
        } catch (Throwable error) {
            log.append("FAIL: ").append(error).append('\n');
            try { screenshot("failure"); writeResults(false, error.toString()); } catch (Throwable ignored) { }
            result.putString("stream", "\n" + log);
            finish(Activity.RESULT_CANCELED, result);
        }
    }

    private MainActivity launchMain() {
        Intent intent = new Intent(getTargetContext(), MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return (MainActivity) startActivitySync(intent);
    }
    private void openExternalSettings() {
        getTargetContext().startActivity(new Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        await(() -> activePackage().equals("com.android.settings"), 15000, "System Settings did not become foreground");
    }
    private String activePackage() {
        AccessibilityNodeInfo root = getUiAutomation().getRootInActiveWindow();
        if (root == null) return "";
        String value=String.valueOf(root.getPackageName());root.recycle();return value;
    }
    private void clearBootDialog() {
        for (int attempt=0;attempt<2;attempt++) {
            AccessibilityNodeInfo root=getUiAutomation().getRootInActiveWindow();
            if(root==null)return;
            java.util.List<AccessibilityNodeInfo> buttons=root.findAccessibilityNodeInfosByViewId("android:id/aerr_wait");
            if(buttons.isEmpty()){root.recycle();return;}
            buttons.get(0).performAction(AccessibilityNodeInfo.ACTION_CLICK);
            bootDialogsWaited++;log.append("ENVIRONMENT: waited for a boot-time system ANR dialog\n");
            root.recycle();SystemClock.sleep(4000);
        }
        AccessibilityNodeInfo root=getUiAutomation().getRootInActiveWindow();
        if(root!=null && !root.findAccessibilityNodeInfosByViewId("android:id/aerr_wait").isEmpty())
            throw new AssertionError("Android system environment is not responsive");
        if(root!=null)root.recycle();
    }
    private void awaitConnected(MainActivity activity) {
        await(() -> service(activity) != null, 15000, "Service bind timeout");
        settle();
    }
    private void click(MainActivity activity, int id) {
        runOnMainSync(() -> activity.findViewById(id).performClick()); settle();
    }
    private CountdownService service(MainActivity activity) {
        final CountdownService[] out = {null};
        runOnMainSync(() -> out[0] = activity.connectedService()); return out[0];
    }
    private long deadline(CountdownService service) {
        final long[] out = {0}; runOnMainSync(() -> out[0] = service.deadlineMs()); return out[0];
    }
    private int remaining(CountdownService service) {
        final int[] out = {0}; runOnMainSync(() -> out[0] = service.remainingSeconds()); return out[0];
    }
    private int listenerCount(CountdownService service) {
        final int[] out = {0}; runOnMainSync(() -> out[0] = service.listenerCount()); return out[0];
    }
    private Snapshot snap(MainActivity activity) {
        Snapshot out = new Snapshot();
        runOnMainSync(() -> {
            Button b = activity.findViewById(R.id.get_code);
            out.enabled = b.isEnabled(); out.button = b.getText().toString();
            out.seconds = activity.displayedSeconds();
            CountdownService s = activity.connectedService();
            out.running = s != null && s.isCounting();
        });
        return out;
    }
    private boolean notificationPresent() {
        return getTargetContext().getSystemService(NotificationManager.class).getActiveNotifications().length > 0;
    }
    private void check(boolean value, String label) throws Exception {
        JSONObject assertion = new JSONObject().put("label", label).put("passed", value)
                .put("observed_elapsed_ms", SystemClock.elapsedRealtime());
        assertions.put(assertion);
        if (!value) throw new AssertionError(label);
        checks++; log.append("PASS ").append(checks).append("  ").append(label).append('\n');
    }
    private void record(String event, MainActivity activity) throws Exception {
        Snapshot s = snap(activity);
        timeline.put(new JSONObject().put("event", event).put("elapsed_ms", SystemClock.elapsedRealtime())
                .put("seconds", s.seconds).put("button", s.button).put("enabled", s.enabled)
                .put("activity", activity.getClass().getSimpleName()));
    }
    private interface Condition { boolean satisfied(); }
    private void await(Condition condition, long timeoutMs, String message) {
        long limit = SystemClock.elapsedRealtime() + timeoutMs;
        while (!condition.satisfied()) {
            if (SystemClock.elapsedRealtime() > limit) throw new AssertionError(message);
            SystemClock.sleep(150);
        }
    }
    private void settle() { waitForIdleSync(); SystemClock.sleep(500); }
    private File dir() {
        File result = new File(getTargetContext().getExternalFilesDir(null), "evidence");
        if (!result.isDirectory() && !result.mkdirs()) throw new IllegalStateException("Evidence directory unavailable");
        return result;
    }
    private void screenshot(String name) throws Exception {
        settle();
        Bitmap bitmap = getUiAutomation().takeScreenshot();
        if (bitmap == null) throw new AssertionError("Screenshot returned no pixels");
        try (FileOutputStream out = new FileOutputStream(new File(dir(), name + ".png"))) {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
        }
        bitmap.recycle();
        AccessibilityNodeInfo root = getUiAutomation().getRootInActiveWindow();
        StringWriter value = new StringWriter();
        XmlSerializer xml = Xml.newSerializer(); xml.setOutput(value);
        xml.startDocument("UTF-8", true); xml.startTag(null, "hierarchy");
        if (root != null) dump(root, xml);
        xml.endTag(null, "hierarchy"); xml.endDocument();
        write(name + ".xml", value.toString());
    }
    private void dump(AccessibilityNodeInfo node, XmlSerializer xml) throws Exception {
        xml.startTag(null, "node");
        xml.attribute(null, "class", String.valueOf(node.getClassName()));
        xml.attribute(null, "text", String.valueOf(node.getText()));
        xml.attribute(null, "resource-id", String.valueOf(node.getViewIdResourceName()));
        xml.attribute(null, "enabled", String.valueOf(node.isEnabled()));
        xml.attribute(null, "clickable", String.valueOf(node.isClickable()));
        Rect bounds = new Rect(); node.getBoundsInScreen(bounds);
        xml.attribute(null, "bounds", bounds.toShortString());
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) { dump(child, xml); child.recycle(); }
        }
        xml.endTag(null, "node");
    }
    private void write(String name, String value) throws Exception {
        try (FileOutputStream out = new FileOutputStream(new File(dir(), name))) {
            out.write(value.getBytes(StandardCharsets.UTF_8));
        }
    }
    private void writeResults(boolean passed, String error) throws Exception {
        write("instrumentation-results.txt", log.toString());
        JSONObject output = new JSONObject().put("passed", passed).put("checks", checks)
            .put("android_release", Build.VERSION.RELEASE).put("api_level", Build.VERSION.SDK_INT)
            .put("device", Build.MODEL).put("recorded_at_epoch_ms", System.currentTimeMillis())
            .put("first_deadline_elapsed_ms", firstDeadline).put("first_start_observed_elapsed_ms", firstObservedStart)
            .put("first_finish_observed_elapsed_ms", firstFinishObserved)
            .put("second_deadline_elapsed_ms", secondDeadline).put("second_finish_observed_elapsed_ms", secondFinishObserved)
            .put("boot_system_dialogs_waited",bootDialogsWaited)
            .put("assertions", assertions).put("timeline", timeline).put("error", error);
        write("results.json", output.toString(2));
    }
    private static class Snapshot { int seconds; boolean enabled; boolean running; String button; }
}
