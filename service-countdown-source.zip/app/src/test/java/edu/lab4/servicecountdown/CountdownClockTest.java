package edu.lab4.servicecountdown;

import org.junit.Test;
import static org.junit.Assert.*;

public class CountdownClockTest {
    @Test public void idleStartsAtZero() { assertEquals(0, new CountdownClock().remainingSeconds(10)); }
    @Test public void durationIsSixtySeconds() { CountdownClock c=new CountdownClock(); c.start(5000); assertEquals(65000,c.deadlineMs()); assertEquals(60,c.remainingSeconds(5000)); }
    @Test public void partialSecondRoundsUp() { CountdownClock c=new CountdownClock(); c.start(100); assertEquals(60,c.remainingSeconds(1099)); }
    @Test public void wholeSecondDecrementsOnce() { CountdownClock c=new CountdownClock(); c.start(100); assertEquals(59,c.remainingSeconds(1100)); }
    @Test public void finalMillisecondIsOneSecond() { CountdownClock c=new CountdownClock(); c.start(100); assertEquals(1,c.remainingSeconds(60099)); }
    @Test public void deadlineAndLaterStayAtZero() { CountdownClock c=new CountdownClock(); c.start(100); assertEquals(0,c.remainingSeconds(60100)); assertEquals(0,c.remainingSeconds(999999)); }
    @Test public void repeatedStartCannotExtendDeadline() { CountdownClock c=new CountdownClock(); assertTrue(c.start(100)); assertFalse(c.start(5100)); assertEquals(60100,c.deadlineMs()); }
    @Test public void finishedCountdownCanStartAgain() { CountdownClock c=new CountdownClock(); c.start(100); assertTrue(c.start(60100)); assertEquals(120100,c.deadlineMs()); assertEquals(60,c.remainingSeconds(60100)); }
}
