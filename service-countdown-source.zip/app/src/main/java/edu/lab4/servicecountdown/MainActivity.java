package edu.lab4.servicecountdown;

import android.Manifest;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends Activity implements CountdownService.Listener {
    private CountdownService service;
    private boolean binding;
    private Button codeButton;
    private TextView state;
    private TextView remaining;
    private ProgressBar progress;
    private int displayedSeconds;
    private boolean hadCountdown;

    private final ServiceConnection connection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name, IBinder binder) {
            service = ((CountdownService.LocalBinder) binder).getService();
            service.addListener(MainActivity.this);
            Log.i("ServiceLab", "UI_CONNECTED " + MainActivity.this.getClass().getSimpleName());
        }
        @Override public void onServiceDisconnected(ComponentName name) {
            service = null;
            codeButton.setEnabled(false);
            state.setText(R.string.reconnecting);
        }
    };

    protected boolean secondaryPage() { return false; }

    @Override protected void onCreate(Bundle stateBundle) {
        super.onCreate(stateBundle);
        setContentView(R.layout.activity_main);
        codeButton = findViewById(R.id.get_code);
        state = findViewById(R.id.state);
        remaining = findViewById(R.id.remaining);
        progress = findViewById(R.id.progress);
        codeButton.setEnabled(false);
        ((TextView) findViewById(R.id.page_title)).setText(secondaryPage() ? R.string.secondary_title : R.string.main_title);
        Button navigate = findViewById(R.id.navigate);
        navigate.setText(secondaryPage() ? R.string.back_main : R.string.open_secondary);
        navigate.setOnClickListener(v -> {
            if (secondaryPage()) finish();
            else startActivity(new Intent(this, AnotherActivity.class));
        });
        codeButton.setOnClickListener(v -> {
            if (service == null || service.isCounting()) return;
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 33);
            }
            Intent intent = new Intent(this, CountdownService.class).setAction(CountdownService.ACTION_START);
            startForegroundService(intent);
        });
        Log.i("ServiceLab", "UI_CREATE " + getClass().getSimpleName());
    }

    @Override protected void onStart() {
        super.onStart();
        binding = bindService(new Intent(this, CountdownService.class), connection, BIND_AUTO_CREATE);
    }
    @Override protected void onStop() {
        if (service != null) service.removeListener(this);
        if (binding) unbindService(connection);
        service = null;
        binding = false;
        Log.i("ServiceLab", "UI_STOP " + getClass().getSimpleName());
        super.onStop();
    }
    @Override protected void onDestroy() {
        Log.i("ServiceLab", "UI_DESTROY " + getClass().getSimpleName());
        super.onDestroy();
    }
    @Override public void onCountdownChanged(int seconds, boolean running) {
        displayedSeconds = seconds;
        if (running) hadCountdown = true;
        codeButton.setEnabled(!running);
        codeButton.setText(running ? getString(R.string.retry_seconds, seconds) : getString(R.string.get_code));
        remaining.setText(running ? getString(R.string.remaining_seconds, seconds) : getString(R.string.ready));
        state.setText(running ? R.string.running : (hadCountdown ? R.string.completed : R.string.idle));
        progress.setProgress(running ? 60 - seconds : (hadCountdown ? 60 : 0));
    }
    // Package-visible read-only state for the real-device instrumentation APK.
    CountdownService connectedService() { return service; }
    int displayedSeconds() { return displayedSeconds; }
}
