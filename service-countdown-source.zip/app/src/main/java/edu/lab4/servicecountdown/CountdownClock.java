package edu.lab4.servicecountdown;

/** A monotonic deadline. The caller supplies SystemClock.elapsedRealtime(). */
public final class CountdownClock {
    public static final long DURATION_MS = 60_000L;
    private long deadlineMs;

    public boolean start(long nowMs) {
        if (remainingSeconds(nowMs) > 0) return false;
        deadlineMs = nowMs + DURATION_MS;
        return true;
    }

    public int remainingSeconds(long nowMs) {
        long remaining = Math.max(0L, deadlineMs - nowMs);
        return (int) ((remaining + 999L) / 1000L);
    }

    public long deadlineMs() { return deadlineMs; }
}
