package edu.lab4.servicecountdown;

/** A second Activity binds to the same started service and reads its current state. */
public final class AnotherActivity extends MainActivity {
    @Override protected boolean secondaryPage() { return true; }
}
