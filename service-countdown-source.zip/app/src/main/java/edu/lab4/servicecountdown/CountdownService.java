package edu.lab4.servicecountdown;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Set;

/** Started lifetime + bound UI clients. No Activity owns a timer. */
public final class CountdownService extends Service {
    public static final String ACTION_START = "edu.lab4.servicecountdown.START";
    private static final String CHANNEL = "verification_countdown";
    public static final int NOTIFICATION_ID = 60;
    private final LocalBinder binder = new LocalBinder();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final CountdownClock clock = new CountdownClock();
    private final Set<Listener> listeners = new LinkedHashSet<>();
    private boolean counting;
    private int lastSeconds = -1;

    public interface Listener { void onCountdownChanged(int seconds, boolean running); }
    public final class LocalBinder extends Binder {
        public CountdownService getService() { return CountdownService.this; }
    }

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            int seconds = remainingSeconds();
            if (seconds != lastSeconds) {
                lastSeconds = seconds;
                event("TICK seconds=" + seconds);
                notifyListeners();
                if (seconds > 0) notificationManager().notify(NOTIFICATION_ID, notification(seconds));
            }
            if (seconds == 0) {
                finishCountdown("FINISH");
                return;
            }
            long left = clock.deadlineMs() - SystemClock.elapsedRealtime();
            long toBoundary = left - (seconds - 1L) * 1000L;
            handler.postDelayed(this, Math.max(1L, Math.min(1000L, toBoundary)));
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        NotificationChannel channel = new NotificationChannel(CHANNEL, "验证码倒计时", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("显示本次60秒倒计时，结束后自动移除");
        notificationManager().createNotificationChannel(channel);
        event("CREATE");
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        event("START_COMMAND");
        if (intent == null || !ACTION_START.equals(intent.getAction())) {
            if (!counting) stopSelf(startId);
            return START_NOT_STICKY;
        }
        boolean fresh = clock.start(SystemClock.elapsedRealtime());
        counting = true;
        promote(remainingSeconds());
        if (fresh) {
            lastSeconds = -1;
            handler.removeCallbacks(ticker);
            handler.post(ticker);
            event("START deadline=" + clock.deadlineMs());
        } else {
            event("DUPLICATE_IGNORED deadline=" + clock.deadlineMs());
            notifyListeners();
        }
        return START_NOT_STICKY;
    }

    private void promote(int seconds) {
        Notification n = notification(seconds);
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SHORT_SERVICE);
        } else if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, n, 0);
        } else {
            startForeground(NOTIFICATION_ID, n);
        }
    }

    @Override public IBinder onBind(Intent intent) { event("BIND"); return binder; }
    @Override public boolean onUnbind(Intent intent) { event("UNBIND"); return true; }
    @Override public void onRebind(Intent intent) { event("REBIND"); super.onRebind(intent); }

    public void addListener(Listener listener) {
        listeners.add(listener);
        listener.onCountdownChanged(remainingSeconds(), isCounting());
    }
    public void removeListener(Listener listener) { listeners.remove(listener); }
    public int remainingSeconds() { return clock.remainingSeconds(SystemClock.elapsedRealtime()); }
    public boolean isCounting() { return counting && remainingSeconds() > 0; }
    public long deadlineMs() { return clock.deadlineMs(); }
    public int listenerCount() { return listeners.size(); }

    private void notifyListeners() {
        for (Listener listener : new ArrayList<>(listeners)) {
            listener.onCountdownChanged(remainingSeconds(), isCounting());
        }
    }
    private void finishCountdown(String reason) {
        counting = false;
        handler.removeCallbacks(ticker);
        stopForeground(STOP_FOREGROUND_REMOVE);
        notifyListeners();
        event(reason);
        stopSelf();
    }
    @Override public void onTimeout(int startId) { finishCountdown("TIMEOUT"); }
    @Override public void onTimeout(int startId, int fgsType) { finishCountdown("TIMEOUT"); }
    @Override public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        listeners.clear();
        stopForeground(STOP_FOREGROUND_REMOVE);
        event("DESTROY");
        super.onDestroy();
    }
    private NotificationManager notificationManager() { return getSystemService(NotificationManager.class); }
    private Notification notification(int seconds) {
        PendingIntent content = PendingIntent.getActivity(this, 0,
            new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_timer).setContentTitle("验证码倒计时进行中")
            .setContentText("剩余 " + seconds + " 秒，返回应用可查看进度")
            .setContentIntent(content).setOnlyAlertOnce(true).setOngoing(true)
            .setProgress(60, Math.max(0, 60 - seconds), false).build();
    }
    private void event(String value) {
        Log.i("ServiceLab", value + " elapsedMs=" + SystemClock.elapsedRealtime() + " listeners=" + listeners.size());
    }
}
