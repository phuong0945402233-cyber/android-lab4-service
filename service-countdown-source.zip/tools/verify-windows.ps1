[CmdletBinding()]
param([switch]$DeviceTests, [string]$Serial = 'emulator-5554', [string]$SdkPath = '', [string]$JavaHome = '')
$ErrorActionPreference = 'Stop'
$PSNativeCommandUseErrorActionPreference = $false
if ($env:OS -ne 'Windows_NT') { throw 'This recorded verification requires Windows.' }
$project = Split-Path -Parent $PSScriptRoot
$result = Join-Path $project ('artifacts/windows/' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Force $result | Out-Null
Set-Location $project
if (-not $SdkPath) { $SdkPath = $env:ANDROID_HOME }
if (-not $JavaHome) { $JavaHome = $env:JAVA_HOME }
$utf8 = [System.Text.UTF8Encoding]::new($false)
[Console]::OutputEncoding = $utf8
$OutputEncoding = $utf8
function Checked([string]$Exe, [string[]]$ArgsList, [string]$LogName) {
    $lines = @(& $Exe @ArgsList 2>&1 | ForEach-Object { $_.ToString() })
    $code = $LASTEXITCODE
    $text = $lines -join [Environment]::NewLine
    [IO.File]::WriteAllText((Join-Path $result $LogName), $text, $utf8)
    Write-Host $text
    if ($code -ne 0) { throw "$Exe exit=$code; see $LogName" }
    return $text
}
try {
    $env:JAVA_HOME = $JavaHome
    $java = Checked (Join-Path $JavaHome 'bin/java.exe') @('-version') 'java-version.txt'
    if ($java -notmatch 'version\s+"17(?:\.|\")') { throw 'JDK 17 is required.' }
    $env:ANDROID_HOME = $SdkPath
    $sdkProperty = $SdkPath.Replace('\','\\').Replace(':','\:')
    [IO.File]::WriteAllText((Join-Path $project 'local.properties'), ('sdk.dir=' + $sdkProperty + "`n"), $utf8)
    [IO.File]::WriteAllText((Join-Path $result 'environment.txt'), (@(
        ('Host: ' + (Get-CimInstance Win32_OperatingSystem).Caption)
        ('Recorded at: ' + (Get-Date -Format o))
        ('JDK: ' + $JavaHome)
        ('SDK: ' + $SdkPath)
        ('Commit: ' + $env:GITHUB_SHA)
    ) -join "`r`n"), $utf8)
    $tasks = @('--no-daemon','--console=plain','assembleDebug','testDebugUnitTest','lintDebug','assembleDebugAndroidTest')
    $null = Checked (Join-Path $project 'gradlew.bat') $tasks 'build-results.txt'
    Copy-Item 'app/build/outputs/apk/debug/app-debug.apk' $result
    Copy-Item 'app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk' $result
    Copy-Item 'app/build/test-results/testDebugUnitTest' (Join-Path $result 'unit-tests') -Recurse
    Copy-Item 'app/build/reports/lint-results-debug.*' $result
    $unitCount = 0
    foreach ($p in Get-ChildItem (Join-Path $result 'unit-tests') -Filter 'TEST-*.xml') {
        [xml]$u = Get-Content $p.FullName -Raw -Encoding utf8
        if ([int]$u.testsuite.failures -ne 0 -or [int]$u.testsuite.errors -ne 0) { throw 'Unit tests failed.' }
        $unitCount += [int]$u.testsuite.tests
    }
    if ($unitCount -ne 8) { throw "Expected eight unit tests; got $unitCount" }
    $summary = "Windows build, 8 JUnit tests and lint: PASS`r`n"
    if ($DeviceTests) {
        $adb = Join-Path $SdkPath 'platform-tools/adb.exe'
        $argsPrefix = @('-s',$Serial)
        $null = Checked $adb ($argsPrefix + @('shell','settings','put','system','show_touches','0')) 'disable-touch-indicator.txt'
        $null = Checked $adb ($argsPrefix + @('shell','settings','put','system','pointer_location','0')) 'disable-pointer-overlay.txt'
        $null = Checked $adb ($argsPrefix + @('shell','wm','dismiss-keyguard')) 'unlock.txt'
        $null = Checked $adb ($argsPrefix + @('logcat','-c')) 'clear-logcat.txt'
        $null = Checked $adb ($argsPrefix + @('install','-r','app/build/outputs/apk/debug/app-debug.apk')) 'install-app.txt'
        $null = Checked $adb ($argsPrefix + @('install','-r','app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk')) 'install-test.txt'
        $output = Checked $adb ($argsPrefix + @('shell','am','instrument','-w','edu.lab4.servicecountdown.test/edu.lab4.servicecountdown.ServiceInstrumentation')) 'instrumentation-results.txt'
        $null = Checked $adb ($argsPrefix + @('pull','/sdcard/Android/data/edu.lab4.servicecountdown/files/evidence',$result)) 'pull-evidence.txt'
        $null = Checked $adb ($argsPrefix + @('logcat','-d','-s','ServiceLab:I','AndroidRuntime:E','*:S')) 'service-lifecycle-logcat.txt'
        $null = Checked $adb ($argsPrefix + @('shell','dumpsys','activity','services','edu.lab4.servicecountdown')) 'service-state-after-tests.txt'
        if ($output -notmatch 'RESULT: PASS; checks=\d+' -or $output -match '(?m)^FAIL:') { throw 'Device checks did not all pass.' }
        $json = Get-Content (Join-Path $result 'evidence/results.json') -Raw -Encoding utf8 | ConvertFrom-Json
        if (-not $json.passed -or $json.checks -lt 20) { throw 'Structured device result failed verification.' }
        $summary += ('Real Android device checks: PASS (' + $json.checks + ")`r`n")
        $summary += "Two complete 60-second countdown cycles: PASS`r`n"
    }
    [IO.File]::WriteAllText((Join-Path $result 'summary.txt'), $summary, $utf8)
    Write-Host $summary
} catch {
    [IO.File]::WriteAllText((Join-Path $result 'failure.txt'), $_.ToString(), $utf8)
    Write-Error $_ -ErrorAction Continue
    exit 1
}
