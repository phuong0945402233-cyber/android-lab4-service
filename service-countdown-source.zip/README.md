# Android Service 60-second countdown

Java teaching project for a verification-code button. A started foreground Service owns the monotonic 60-second deadline; Activities bind only while visible and receive one-second state callbacks. It does not send SMS or make network requests.

## Build and run

Open this folder in Android Studio with JDK 17. Install Android SDK Platform 35 and Build Tools 34.0.0. On Windows run `gradlew.bat assembleDebug testDebugUnitTest lintDebug assembleDebugAndroidTest`. The app supports Android 8.0/API 26 and above.

Package: `edu.lab4.servicecountdown`. The debug APK is `app/build/outputs/apk/debug/app-debug.apk`.

## Verification

The project includes a prepared Windows workflow to build the app, run eight deadline unit tests, start an official Android emulator, run the real-device instrumentation (including two complete 60-second cycles), and import/run the project in Android Studio. This Windows workflow has not been executed for this experiment. Actual local build and Android emulator evidence is provided separately in the experiment package; Windows and Android Studio validation remain pending. No test result is assumed before the corresponding verification passes.

The foreground service uses the `shortService` type on Android 14 and above. It removes its notification and calls `stopSelf()` after completion. Background continuation means temporary navigation away from the visible Activity; force-stop, reboot and indefinite process survival are outside this exercise.

On Android 13+, the app asks for notification permission when starting a countdown. The countdown itself still uses a foreground service if notification permission is denied.

This project contains generic experiment code only; student names, reports and personal account data are kept outside the project.
